import React from 'react';

function Error(){
    return(
        <div>
            <h4>These aren't the droids you're looking for!</h4>
            <img alt="not the droids" src="https://www.nme.com/wp-content/uploads/2019/10/2019_obiwan_2000x1270.png"></img>
        </div>
    )

}
export default Error;